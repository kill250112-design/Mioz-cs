# CS2 — Кейсы

Мобильное демо-приложение в тёмном стиле Telegram Mini App: открытие кейсов с анимированной рулеткой, локальный баланс и инвентарь.

> **Важно о ценах и экономике:** цены скинов в проекте — демонстрационные значения из задания, записанные в локальный каталог. Это не live-котировки Steam/CSFloat и они автоматически не обновляются. Баланс, выпадения и продажа работают только на стороне браузера; пополнение, реальные платежи, аккаунты и серверная проверка не реализованы. Не используйте демо как сервис азартных игр или торговли.

## Возможности

- Vite 5, отдельные HTML/CSS/JS-файлы.
- 4 кейса и веса выпадения, заданные в `public/js/app.js`.
- Рулетка из 70 карточек, остановка на позиции 52, эффект подсветки и конфетти.
- Выигрыш добавляется в инвентарь; продажа возвращает полную указанную цену.
- Баланс и инвентарь сохраняются в `localStorage` под ключом `cs2game`.
- Адаптивный мобильный интерфейс, safe-area для iPhone.
- GitHub Actions автоматически публикует сборку на GitHub Pages при push в `main`.

## Локальный запуск

Требуется Node.js 20 или новее.

```bash
npm install
npm run dev
```

Для проверки production-сборки:

```bash
npm run build
npm run preview
```

## Как загрузить на GitHub

1. Создайте новый пустой репозиторий на GitHub, например `cs2-cases`.
2. Распакуйте архив проекта и откройте терминал в папке `cs2-cases`.
3. Выполните команды:

```bash
git init
git add .
git commit -m "Initial CS2 Cases app"
git branch -M main
git remote add origin https://github.com/ВАШ_АККАУНТ/cs2-cases.git
git push -u origin main
```

Замените `ВАШ_АККАУНТ` на свой GitHub username.

## Включение GitHub Pages

1. Откройте репозиторий на GitHub.
2. Перейдите в **Settings → Pages**.
3. В поле **Build and deployment → Source** выберите **GitHub Actions**.
4. После push в `main` откройте вкладку **Actions** и дождитесь завершения workflow `Deploy to GitHub Pages`.
5. Адрес опубликованного сайта появится в deployment / Settings → Pages.

Workflow расположен в `.github/workflows/deploy.yml`. Он использует Node 20, устанавливает зависимости, выполняет `npm run build`, загружает `dist` и публикует Pages.

## Иконки и изображения

Положите PNG-файлы в `public/images/`. Путь к каталогу задаётся константой `IMAGE_PATH = 'images/'` в `public/js/app.js`. Если изображение отсутствует или не загрузилось, интерфейс показывает эмодзи-заглушку.

**Иконки кейсов:**

- `case-start.png`
- `case-prime.png`
- `case-legend.png`
- `case-knife.png`

**Иконки скинов:**

- `p250-sand.png`
- `mp9-storm.png`
- `galil-camo.png`
- `ak-blue-laminate.png`
- `awp-dragon.png`
- `usp-forest.png`
- `famas-neuron.png`
- `m4a4-howl.png`
- `awp-asiimov.png`
- `karambit-fade.png`
- `glock-water.png`
- `ak-fire-serpent.png`
- `awp-hyper-beast.png`
- `karambit-crimson-web.png`
- `gloves-spectrum.png`
- `bayonet-forest.png`
- `butterfly-waves.png`
- `karambit-fade-fn.png`
- `karambit-ruby.png`

В архиве `public/images/.gitkeep` сохраняет пустую папку в Git. Используйте изображения, на которые у вас есть права.

## Настройки и каталог

Изменяйте названия, цены и веса в массиве `CASES` в `public/js/app.js`. Порядок весов соответствует предметам внутри кейса. Названия файлов изображений настраиваются в объектах `IMAGES` и `CASE_IMAGES`.

## Ограничения демо

- Все данные хранятся локально в браузере и могут быть сброшены очисткой localStorage.
- Результат открытия кейса выбирается на клиенте, поэтому это не защищённая игровая экономика.
- Кнопка «Пополнить» показывает демо-уведомление. Для настоящих платежей и актуальных цен потребуются сервер, безопасный API и соблюдение правил платёжных провайдеров и торговых площадок.
