const IMAGE_PATH = 'images/';

const IMAGES = {
  'P250 | Песок': IMAGE_PATH + 'p250-sand.png',
  'MP9 | Шторм': IMAGE_PATH + 'mp9-storm.png',
  'Galil | Камуфляж': IMAGE_PATH + 'galil-camo.png',
  'AK-47 | Синий ламинат': IMAGE_PATH + 'ak-blue-laminate.png',
  'AWP | Драконий огонь': IMAGE_PATH + 'awp-dragon.png',
  'USP-S | Лесной': IMAGE_PATH + 'usp-forest.png',
  'FAMAS | Нейрон': IMAGE_PATH + 'famas-neuron.png',
  'M4A4 | Вой': IMAGE_PATH + 'm4a4-howl.png',
  'AWP | Азимов': IMAGE_PATH + 'awp-asiimov.png',
  'Керамбит | Градиент': IMAGE_PATH + 'karambit-fade.png',
  'Glock | Водный': IMAGE_PATH + 'glock-water.png',
  'AK-47 | Огненный змей': IMAGE_PATH + 'ak-fire-serpent.png',
  'AWP | Гипербист': IMAGE_PATH + 'awp-hyper-beast.png',
  'Керамбит | Кровавая паутина': IMAGE_PATH + 'karambit-crimson-web.png',
  'Перчатки | Спектр': IMAGE_PATH + 'gloves-spectrum.png',
  'Штык-нож | Лес': IMAGE_PATH + 'bayonet-forest.png',
  'Бабочка | Волны': IMAGE_PATH + 'butterfly-waves.png',
  'Керамбит | Градиент (FN)': IMAGE_PATH + 'karambit-fade-fn.png',
  'Керамбит | Рубин': IMAGE_PATH + 'karambit-ruby.png'
};

const CASE_IMAGES = {
  start: IMAGE_PATH + 'case-start.png',
  prime: IMAGE_PATH + 'case-prime.png',
  legend: IMAGE_PATH + 'case-legend.png',
  knife: IMAGE_PATH + 'case-knife.png'
};

const RARITIES = {
  milspec: { label: 'Mil-Spec', color: '#4b69ff' },
  restricted: { label: 'Restricted', color: '#8847ff' },
  classified: { label: 'Classified', color: '#d32ce6' },
  covert: { label: 'Covert', color: '#eb4b4b' },
  rare: { label: 'Rare Special', color: '#ffd700' }
};

const CASES = [
  { id: 'start', name: 'Стартовый кейс', price: 100, description: 'Отличный старт коллекции', emoji: '📦', drops: [
    ['P250 | Песок','milspec',50,60], ['MP9 | Шторм','milspec',120,25], ['Galil | Камуфляж','restricted',350,10], ['AK-47 | Синий ламинат','classified',1800,4], ['AWP | Драконий огонь','covert',345881,1]
  ]},
  { id: 'prime', name: 'Прайм кейс', price: 250, description: 'Для настоящих ценителей', emoji: '🧰', drops: [
    ['USP-S | Лесной','milspec',80,50], ['FAMAS | Нейрон','restricted',450,30], ['M4A4 | Вой','classified',328670,15], ['AWP | Азимов','covert',12000,4], ['Керамбит | Градиент','rare',121186,1]
  ]},
  { id: 'legend', name: 'Легендарный кейс', price: 500, description: 'Шанс на легендарный дроп', emoji: '💎', drops: [
    ['Glock | Водный','restricted',600,45], ['AK-47 | Огненный змей','classified',231516,30], ['AWP | Гипербист','covert',45000,18], ['Керамбит | Кровавая паутина','rare',85000,5], ['Перчатки | Спектр','rare',95000,2]
  ]},
  { id: 'knife', name: 'Ножевой кейс', price: 1000, description: 'Только острые ощущения', emoji: '🔪', drops: [
    ['Штык-нож | Лес','restricted',3500,40], ['Бабочка | Волны','classified',147437,30], ['Керамбит | Градиент (FN)','covert',202202,20], ['Керамбит | Кровавая паутина','rare',85000,8], ['Керамбит | Рубин','rare',250000,2]
  ]}
];

const $ = (id) => document.getElementById(id);
const money = (n) => `${Math.round(n).toLocaleString('ru-RU')} ₽`;
const compactMoney = (n) => n < 1000 ? `${n} ₽` : n < 1_000_000 ? `${(n/1000).toFixed(1).replace('.0','')}K ₽` : `${(n/1_000_000).toFixed(1).replace('.0','')}M ₽`;
const fallback = (el, emoji = '📦') => { el.onerror = null; el.replaceWith(Object.assign(document.createElement('span'), { className: el.className, textContent: emoji })); };
const imageMarkup = (src, alt, cls, emoji='📦') => `<img class="${cls}" src="${src}" alt="${alt}" onerror="this.onerror=null;const s=document.createElement('span');s.className=this.className;s.textContent='${emoji}';this.replaceWith(s)">`;

let state = loadState();
let currentFilter = 'all';
let pendingDrop = null;
let rolling = false;

function loadState() {
  try {
    const saved = JSON.parse(localStorage.getItem('cs2game'));
    if (saved && Number.isFinite(saved.balance) && Array.isArray(saved.inventory)) return { balance: saved.balance, inventory: saved.inventory };
  } catch (_) {}
  return { balance: 1000, inventory: [] };
}
function saveState() { localStorage.setItem('cs2game', JSON.stringify(state)); }
function updateWallet() {
  $('balance').textContent = `💰 ${Math.floor(state.balance).toLocaleString('ru-RU')}`;
  $('inventoryCount').textContent = state.inventory.length;
  $('inventoryTotal').textContent = `${state.inventory.length} предметов`;
}
function showNotice(message) {
  const node = $('notice'); node.textContent = message; node.classList.add('show');
  clearTimeout(showNotice.timer); showNotice.timer = setTimeout(() => node.classList.remove('show'), 2200);
}
function renderCases() {
  const query = ($('caseSearch').value || '').trim().toLowerCase();
  const list = CASES.filter(c => (currentFilter === 'all' || c.id === currentFilter) && c.name.toLowerCase().includes(query));
  $('caseGrid').innerHTML = list.map(c => `
    <article class="case-card">
      <div class="case-art">${imageMarkup(CASE_IMAGES[c.id], c.name, 'case-photo', c.emoji).replace('case-photo','case-photo')}</div>
      <h3 class="case-name">${c.name}</h3><p class="case-desc">${c.description}</p>
      <div class="case-footer"><span class="case-price">💰 ${c.price.toLocaleString('ru-RU')}</span><button class="open-btn" data-open="${c.id}" ${state.balance < c.price ? 'disabled' : ''}>Открыть</button></div>
    </article>`).join('') || '<div class="empty-state">Ничего не найдено</div>';
  $('caseGrid').querySelectorAll('[data-open]').forEach(btn => btn.addEventListener('click', () => openCase(btn.dataset.open)));
}
function renderInventory() {
  const grid = $('inventoryGrid');
  if (!state.inventory.length) {
    grid.innerHTML = '<div class="empty-state">📭<br>Инвентарь пуст, открой кейс</div>';
    updateWallet(); return;
  }
  grid.innerHTML = state.inventory.map((item, index) => `
    <article class="inventory-item">
      <div class="inventory-image" style="border-bottom:2px solid ${RARITIES[item.rarity]?.color || '#777'}">${imageMarkup(IMAGES[item.name] || '', item.name, 'inventory-photo')}</div>
      <div class="inventory-name">${item.name}</div>
      <div class="inventory-price">${compactMoney(item.price)}</div>
      <button class="sell-btn" data-sell="${index}">Продать</button>
    </article>`).join('');
  grid.querySelectorAll('[data-sell]').forEach(btn => btn.addEventListener('click', () => sellItem(Number(btn.dataset.sell))));
  updateWallet();
}
function selectPage(page) {
  const inventory = page === 'inventory';
  $('casesPage').classList.toggle('hidden', inventory);
  $('inventoryPage').classList.toggle('hidden', !inventory);
  document.querySelectorAll('.tab').forEach(b => b.classList.toggle('active', b.dataset.page === (inventory ? 'inventory' : 'cases')));
  document.querySelectorAll('.nav-item').forEach(b => b.classList.toggle('active', b.dataset.page === page || (page === 'home' && b.dataset.page === 'home')));
  if (inventory) renderInventory();
}
function chooseDrop(caseData) {
  const total = caseData.drops.reduce((sum, d) => sum + d[3], 0);
  let roll = Math.random() * total;
  for (const drop of caseData.drops) { roll -= drop[3]; if (roll < 0) return drop; }
  return caseData.drops[0];
}
function makeDrop(drop) { return { name: drop[0], rarity: drop[1], price: drop[2] }; }
function openCase(id) {
  if (rolling) return;
  const c = CASES.find(x => x.id === id);
  if (!c || state.balance < c.price) { showNotice('Недостаточно средств'); return; }
  state.balance -= c.price; saveState(); updateWallet(); renderCases();
  rolling = true; pendingDrop = makeDrop(chooseDrop(c));
  $('rouletteTitle').textContent = c.name;
  $('rouletteStatus').textContent = 'Прокручиваем рулетку...';
  $('rouletteOverlay').classList.remove('hidden');
  const track = $('rouletteTrack'); track.style.transition = 'none'; track.style.transform = 'translateX(0)';
  const entries = Array.from({ length: 70 }, (_, i) => i === 52 ? pendingDrop : makeDrop(chooseDrop(c)));
  track.innerHTML = entries.map((item, i) => `<div class="roulette-item ${i === 52 ? 'winner' : ''}" data-index="${i}" style="border-bottom:3px solid ${RARITIES[item.rarity].color}"><div class="item-art">${imageMarkup(IMAGES[item.name] || '', item.name, 'reel-img')}</div><div class="item-name">${item.name}</div></div>`).join('');
  const winner = track.querySelector('[data-index="52"]');
  const trackRect = track.getBoundingClientRect();
  const winnerCenter = 10 + 52 * (104 + 8) + 52;
  const target = trackRect.width / 2 - winnerCenter + (Math.random() * 60 - 30);
  requestAnimationFrame(() => requestAnimationFrame(() => {
    track.style.transition = 'transform 5.5s cubic-bezier(0.12, 0.8, 0.2, 1)';
    track.style.transform = `translateX(${target}px)`;
  }));
  setTimeout(() => {
    rolling = false;
    winner.classList.add('winner-pulse');
    $('rouletteStatus').textContent = 'Готово! Твой выигрыш определён';
    setTimeout(showWin, 650);
  }, 5650);
}
function showWin() {
  if (!pendingDrop) return;
  $('rouletteOverlay').classList.add('hidden');
  const item = pendingDrop, rarity = RARITIES[item.rarity];
  $('winImage').innerHTML = imageMarkup(IMAGES[item.name] || '', item.name, 'won-image');
  $('winTitle').textContent = item.name;
  $('winRarity').textContent = rarity.label;
  $('winRarity').style.color = rarity.color;
  $('winRarity').style.border = `1px solid ${rarity.color}70`;
  $('winPrice').textContent = money(item.price);
  $('winOverlay').classList.remove('hidden');
  if (item.rarity === 'covert' || item.rarity === 'rare') launchConfetti();
}
function claimWin() {
  if (!pendingDrop) return;
  state.inventory.unshift(pendingDrop); pendingDrop = null; saveState(); updateWallet(); renderCases();
  $('winOverlay').classList.add('hidden'); showNotice('Предмет добавлен в инвентарь');
}
function sellItem(index) {
  const item = state.inventory[index]; if (!item) return;
  state.balance += item.price; state.inventory.splice(index, 1);
  saveState(); updateWallet(); renderInventory(); renderCases(); showNotice(`Продано за ${money(item.price)}`);
}
function launchConfetti() {
  for (let i=0; i<65; i++) {
    const bit = document.createElement('i'); bit.className = 'confetti';
    bit.style.left = `${Math.random()*100}vw`; bit.style.animationDelay = `${Math.random()*.65}s`;
    bit.style.background = ['#ffd700','#7b61ff','#eb4b4b','#4b69ff','#fff'][i%5];
    bit.style.transform = `rotate(${Math.random()*360}deg)`; document.body.appendChild(bit);
    setTimeout(() => bit.remove(), 3200);
  }
}

document.querySelectorAll('.tab').forEach(btn => btn.addEventListener('click', () => selectPage(btn.dataset.page)));
document.querySelectorAll('.nav-item').forEach(btn => btn.addEventListener('click', () => selectPage(btn.dataset.page)));
document.querySelectorAll('.filter').forEach(btn => btn.addEventListener('click', () => {
  currentFilter = btn.dataset.filter;
  document.querySelectorAll('.filter').forEach(b => b.classList.toggle('active', b === btn));
  renderCases();
}));
$('searchToggle').addEventListener('click', () => { $('searchWrap').classList.toggle('hidden'); if (!$('searchWrap').classList.contains('hidden')) $('caseSearch').focus(); });
$('caseSearch').addEventListener('input', renderCases);
$('topupBtn').addEventListener('click', () => showNotice('Пополнение доступно в демо-режиме через игровую валюту'));
$('battleBtn').addEventListener('click', () => showNotice('Кейс-батлы скоро появятся!'));
$('claimBtn').addEventListener('click', claimWin);
$('winClose').addEventListener('click', claimWin);
$('rouletteClose').addEventListener('click', () => { if (!rolling) { $('rouletteOverlay').classList.add('hidden'); showNotice('Выигрыш сохранён после остановки рулетки'); } });
$('balance').title = 'Демо-баланс сохраняется на этом устройстве';
updateWallet(); renderCases(); renderInventory();
